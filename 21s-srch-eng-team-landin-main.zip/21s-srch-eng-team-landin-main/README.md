# Search Engine (Spring 2021) 

- [Project Handout](https://docs.google.com/document/d/12IeSu8jHuZMUe4wZO8gnNd26-nkpnZIR4sJcYpw8Bdg/edit?usp=sharing)

### Note: 

Do not attempt to run large data sets through Github Actions!  You can provide a few sample articles as proof that things are working.  Save the large parsing and indexing for your local machine. 

